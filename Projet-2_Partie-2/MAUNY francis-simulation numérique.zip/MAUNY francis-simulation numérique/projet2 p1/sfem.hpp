// la regle de programmation 3
#include "assertion.hpp" 
#include <cstdlib>
// some usefull function
template<class T> inline T Min (const T &a,const T &b){return a < b ? a : b;}
template<class T> inline T Max (const T &a,const T & b){return a > b ? a : b;}
template<class T> inline T Abs (const T &a){return a <0 ? -a : a;}
template<class T> inline double Norme (const T &a){return sqrt(a*a);}
template<class T> inline void Exchange (T& a,T& b) {T c=a;a=b;b=c;}
template<class T> inline T Max (const T &a,const T & b,const T & c){return Max(Max(a,b),c);}
template<class T> inline T Min (const T &a,const T & b,const T & c){return Min(Min(a,b),c);}

using namespace std;
// definition R
typedef double R;

// The class R2
class R2 {

public:  
  R x,y;
  R2 () :x(0),y(0) {}
  R2 (R a,R b):x(a),y(b)  {}
  R2 (R2 a,R2 b):x(b.x-a.x),y(b.y-a.y)  {}
  R2   operator+(R2 P)const   {return R2(x+P.x,y+P.y);}
  R2   operator+=(R2 P)  {x += P.x;y += P.y;return *this;}
  R2   operator-(R2 P)const   {return R2(x-P.x,y-P.y);}
  R2   operator-=(R2 P) {x -= P.x;y -= P.y;return *this;}
  R2   operator-()const  {return R2(-x,-y);}
  R2   operator+()const  {return *this;}
  R   operator,(R2 P)const  {return  x*P.x+y*P.y;} // produit scalaire
  R   operator^(R2 P)const {return  x*P.y-y*P.x;} // produit mixte
  R2   operator*(R c)const {return R2(x*c,y*c);}
  R2   operator/(R c)const {return R2(x/c,y/c);}
  R2   perp() {return R2(-y,x);} // the perpendiculare
};
 R2 operator*(R c,R2 P) {return P*c;}
 ostream& operator <<(ostream& f, const R2 & P )
       { f << P.x << ' ' << P.y   ; return f; }
 istream& operator >>(istream& f,  R2 & P)
       { f >>  P.x >>  P.y  ; return f; }

class Label {  // reference number for the physics
  public: 
  int lab;
  Label(int r=0):lab(r){}
  bool onGamma() const { return lab;} 
  };
ostream& operator <<(ostream& f,const Label & r  )
{ f <<  r.lab ; return f; }
istream& operator >>(istream& f, Label & r  )
{ f >>  r.lab ; return f; }

  
class Vertex : public R2,public Label {
   public:
   Vertex() : R2(),Label(){};
   Vertex(R2 P,int r=0): R2(P),Label(r){}
};
ostream& operator <<(ostream& f, const Vertex & v )
{ f << (R2) v << ' ' << (Label &) v   ; return f; }
istream& operator >> (istream& f,  Vertex & v )
{ f >> (R2 &) v >> (Label &) v ; return f; }


class Triangle: public Label {
  Vertex *vertices[3]; // an array of 3 pointer to vertex
public:
  R area;
  Triangle(){}; // constructor empty for array
  Vertex & operator[](int i) const {
    ASSERTION(i>=0 && i <3);
    return *vertices[i];} // to see traingle as a array of vertex
  void set(Vertex * v0,int i0,int i1,int i2,int r) 
  {
    vertices[0]=v0+i0; vertices[1]=v0+i1; vertices[2]=v0+i2; 
    R2 AB(*vertices[0],*vertices[1]);
    R2 AC(*vertices[0],*vertices[2]);
    area = (AB^AC)*0.5;
    lab=r;
    ASSERTION(area>=0);    
  }
  R2 Edge(int i) const {
    ASSERTION(i>=0 && i <3);
    return R2(*vertices[(i+1)%3],*vertices[(i+2)%3]);}// opposite edge vertex i
  R2 H(int i) const { 
    ASSERTION(i>=0 && i <3);
    R2 E=Edge(i);return E.perp()/(2*area);} // heigth 
  R lenEdge(int i) const {
    ASSERTION(i>=0 && i <3);
    R2 E=Edge(i);return sqrt((E,E));}
private:
  Triangle(const Triangle &); // pas de construction par copie
  void operator=(const Triangle &);// pas affectation par copy 
};

class Mesh { public:
  int nt,nv;
  R area;
  Vertex *vertices;
  Triangle *triangles;
  Triangle & operator[](int i) const {return triangles[CheckT(i)];}
  Vertex & operator()(int i) const {return vertices[CheckV(i)];}
  inline Mesh(const char * filename); // read on a file
  int operator()(const Triangle & t) const {return CheckT(&t - triangles);}
  int operator()(const Triangle * t) const {return CheckT(t - triangles);}
  int operator()(const Vertex & v) const {return CheckV(&v - vertices);}
  int operator()(const Vertex * v) const{return CheckT(v - vertices);}
  int operator()(int it,int j) const {return (*this)(triangles[it][j]);}// Nu vertex j of traingle it
  //  to check the bound 
  int CheckV(int i) const { ASSERTION(i>=0 && i < nv); return i;} 
  int CheckT(int i) const { ASSERTION(i>=0 && i < nt); return i;}
 private:
   Mesh(const Mesh &); // pas de construction par copie
   void operator=(const Mesh &);// pas affectation par copy 
   
};


inline Mesh::Mesh(const char * filename)
 { // read the mesh
   int i,neb,i0,i1,i2,ir;
   ifstream f(filename);
   if(!f) {cerr << "Mesh::Mesh Erreur openning " << filename<<endl;exit(1);}
   cout << " Read On file \"" <<filename<<"\""<<  endl;
   f >> nv >> nt >> neb ;
   cout << " Nb of Vertex " << nv << " " << " Nb of Triangles " << nt << endl;
   assert(f.good() && nt && nv) ;
   triangles = new Triangle [nt];
   vertices = new Vertex[nv];
   area=0;
   assert(triangles && vertices);
   for (i=0;i<nv;i++)    
     f >> vertices[i],assert(f.good());
   for (i=0;i<nt;i++) { 
       f >> i0 >> i1 >> i2 >> ir;
       assert(f.good() && i0>0 && i0<=nv && i1>0 && i1<=nv && i2>0 && i2<=nv);
       triangles[i].set(vertices,i0-1,i1-1,i2-1,ir); 
       area += triangles[i].area;}
   cout << " End of read: area = " << area <<endl;  
 }
 
