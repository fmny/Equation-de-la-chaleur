#include <cmath>
#include <iostream>
#include <fstream>
#include <cassert>
#include "sfem.hpp"
int  BuildEdges(const Mesh & Th,int (* arete)[2], int nbex) ;
