
//  un exemple utilisation de classe derive
//  ou heritage
//  plus une encaopsulation d'un pointeur 
// pour obtenir un objet 
// avec les destructeur 

#include <iostream>
 // pour la fonction pow 
#include <cmath>
 
typedef double R;

class Cvirt0 {  public:
  virtual R operator()( ) const =0;
  virtual ~Cvirt0() { } //std::cout << "~"<< this << "\n";}   //  
  virtual Cvirt0 * copy() const = 0;  // 
private: // pas de copy  mais aucun constructeur
  void operator=(const Cvirt0 &);
};

class Ccomp0 : public Cvirt0 { public: 
  R (*f)(R); 
  Cvirt0 * g;
  R operator()() const { return (*f)((*g)() );}
  Ccomp0( R (*ff)(R),Cvirt0 * gg) : f(ff),g(gg) {} 
  Cvirt0 * copy() const { return new Ccomp0(f,g->copy());}
  ~Ccomp0() { delete g;}
};

class Cconst : public Cvirt0 { public: 
  R a;
  R operator()( ) const { return a;}
  Cconst( R aa) : a(aa) {} 
  Cvirt0 * copy() const { return new Cconst(*this);}
  ~Cconst() { }  
};

class CconstviaPointeur : public Cvirt0 { public: 
  R *a;
  R operator()( ) const { return *a;}
  CconstviaPointeur( R *aa) : a(aa) {} 
  Cvirt0 * copy() const { return new CconstviaPointeur(*this);}
  ~CconstviaPointeur() { }

}; 

class Coper : public Cvirt0 { public: 
  const  Cvirt0 *g, *d;
  R (*op)(R,R); 
  R operator()() const { return (*op)((*g)(),(*d)());}
  Coper( R (*opp)(R,R), const Cvirt0 *gg, const Cvirt0 *dd) : op(opp),g(gg),d(dd) {} 
  ~Coper(){delete g;delete d;}
  Coper(const Coper & f) :op(f.op), g(f.g->copy()),d(f.d->copy()) {}
  Cvirt0 * copy() const { return new Coper(*this);}
};



//  les 5 operateur binaire
static  R minus(R a) {return -a;}
static  R Add(R a,R b) {return a+b;}
static  R Sub(R a,R b) {return a-b;}
static  R Mul(R a,R b) {return a*b;}
static  R Div(R a,R b) {return a/b;}
static  R Pow(R a,R b) {return pow(a,b);}


class Fonction0 { public:
  const Cvirt0 *f;
  R operator()(){ return (*f)();}

  Fonction0(const Cvirt0 *ff) : f(ff) {}
  const Cvirt0 * copy() const { return f->copy();}

  Fonction0(R a) : f(new Cconst(a)) {}
  Fonction0(R * pa) : f(new CconstviaPointeur(pa)) {}
  operator  Cvirt0  * () const {return f->copy();}
  //   tous les operateurs pas de cop du pointeur  f, car toutes les class intermedaires
  // sont detruite 
  Fonction0 operator+() const {return f->copy();}
  Fonction0 operator-() const {return new Ccomp0(minus,f->copy());}

  Fonction0 operator+(const Fonction0 & dd) const {return new Coper(Add,*this,dd);}
  Fonction0 operator-(const Fonction0 & dd) const {return new Coper(Sub,*this,dd);}
  Fonction0 operator*(const Fonction0 & dd) const {return new Coper(Mul,*this,dd);}
  Fonction0 operator/(const Fonction0 & dd) const {return new Coper(Div,*this,dd);}
  Fonction0 operator^(const Fonction0 & dd) const {return new Coper(Pow,*this,dd);}
  //
  ~Fonction0() { delete f;} // std::cout << " delete f "<< f << "\n";}
  //  les operateurs de copie
  Fonction0(const Fonction0 & F) : f(F.f->copy()) {}
  Fonction0 operator=(const Fonction0 & F)  { delete f; f=F.copy();return *this;}
  Fonction0 operator*=(const Fonction0 & F)  { *this = *this*F ;return *this;}
  Fonction0 operator/=(const Fonction0 & F)  { *this = *this/F ;return *this;}
  Fonction0 operator+=(const Fonction0 & F)  { *this = *this+F ;return *this;}
  Fonction0 operator-=(const Fonction0 & F)  { *this = *this-F ;return *this;}
};

Fonction0 compose(R (* f)(R ),const  Fonction0 & g)
{ return new Ccomp0(f,g);}
//  les 4 operateurs sur les fonctions
